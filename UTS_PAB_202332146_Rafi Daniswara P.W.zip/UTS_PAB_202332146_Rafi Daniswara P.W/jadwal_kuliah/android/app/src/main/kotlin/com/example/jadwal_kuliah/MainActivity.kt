package com.example.jadwal_kuliah

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
