// File: lib/pages/dashboard_page.dart

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/jadwal_model.dart';
import 'detail_page.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final List<Jadwal> _daftarJadwal = [];

  int get _tugasSelesaiCount {
    return _daftarJadwal.where((j) => j.status == 'Selesai').length;
  }

  void _bukaHalamanDetail({Jadwal? jadwal, int? index}) async {
    final hasil = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DetailPage(
          jadwalToEdit: jadwal,
        ),
      ),
    );

    if (hasil != null && hasil is Jadwal) {
      setState(() {
        if (index == null) {
          _daftarJadwal.add(hasil);
        } else {
          _daftarJadwal[index] = hasil;
        }
      });
    }
  }
  
  bool _isSameDay(DateTime dateA, DateTime dateB) {
    return dateA.year == dateB.year &&
           dateA.month == dateB.month &&
           dateA.day == dateB.day;
  }
  
  List<Jadwal> _getJadwalFor(DateTime targetDate) {
    final DateFormat parser = DateFormat('dd/MM/yyyy');
    List<Jadwal> jadwalDitemukan = [];

    for (var jadwal in _daftarJadwal) {
      try {
        final DateTime jadwalDate = parser.parse(jadwal.tanggal);
        
        if (_isSameDay(jadwalDate, targetDate)) {
          if (jadwal.status == 'Pending') {
            jadwalDitemukan.add(jadwal);
          }
        }
      } catch (e) {
        debugPrint('Format tanggal salah: ${jadwal.tanggal}');
      }
    }
    return jadwalDitemukan;
  }


  @override
  Widget build(BuildContext context) {
    final DateTime hariIni = DateTime.now();
    final DateTime besok = hariIni.add(const Duration(days: 1));
    
    final List<Jadwal> jadwalHariIni = _getJadwalFor(hariIni);
    final List<Jadwal> jadwalBesok = _getJadwalFor(besok);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Aplikasi Pengingat Jadwal'),
        
        // --- INI TAMBAHAN BARUNYA ---
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Log Out', // Teks yang muncul saat ikon ditahan
            onPressed: () {
              // Navigasi kembali ke Login dan hapus semua riwayat navigasi
              Navigator.pushNamedAndRemoveUntil(
                context,
                '/login', // Kembali ke rute '/login'
                (Route<dynamic> route) => false, // Hapus semua rute sebelumnya
              );
            },
          ),
        ],
        // --- BATAS AKHIR TAMBAHAN ---
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.all(16.0),
              child: Text(
                'Ringkasan Aktivitas',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            _buildRingkasanCard(), 
            
            Row(
              children: [
                Expanded(
                  child: _buildJadwalSingkatCard(
                    'Jadwal Hari Ini',
                    jadwalHariIni,
                  ),
                ),
                Expanded(
                  child: _buildJadwalSingkatCard(
                    'Jadwal Besok',
                    jadwalBesok,
                  ),
                ),
              ],
            ),
            
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Semua Jadwal',
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 16),
                    _buildSearchBar(context),
                    const SizedBox(height: 16),
                    Text(
                        'Menampilkan ${_daftarJadwal.length} dari total ${_daftarJadwal.length} jadwal.'),
                    const SizedBox(height: 16),
                    _buildJadwalTable(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRingkasanCard() {
    return Card(
      color: Colors.pink,
      margin: const EdgeInsets.symmetric(horizontal: 16),
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Row(
          children: [
            const Icon(Icons.task_alt, color: Colors.white, size: 32),
            const SizedBox(width: 16),
            Text(
              '$_tugasSelesaiCount\nKegiatan Selesai',
              style: const TextStyle(color: Colors.white, fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildJadwalSingkatCard(String title, List<Jadwal> listJadwal) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.calendar_month, size: 18, color: Colors.pink),
                const SizedBox(width: 8),
                Text(title,
                    style: const TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 8),
            
            if (listJadwal.isEmpty)
              const Text(
                'Tidak ada jadwal.',
                style: TextStyle(color: Colors.grey),
              ),
              
            if (listJadwal.isNotEmpty)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: listJadwal.map((jadwal) => Text(
                  '• ${jadwal.judul}',
                  style: const TextStyle(color: Colors.black87),
                  overflow: TextOverflow.ellipsis,
                )).toList(),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchBar(BuildContext context) {
    return Row(
      children: [
        const Expanded(
          child: TextField(
            decoration: InputDecoration(
              hintText: 'Cari jadwal...',
              prefixIcon: Icon(Icons.search),
            ),
          ),
        ),
        const SizedBox(width: 8),
        ElevatedButton.icon(
          onPressed: () => _bukaHalamanDetail(
            jadwal: null,
            index: null,
          ),
          icon: const Icon(Icons.add, size: 18),
          label: const Text('Tambah Jadwal'),
          style: ElevatedButton.styleFrom(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
            backgroundColor: Colors.pink,
            foregroundColor: Colors.white,
          ),
        ),
      ],
    );
  }

  Widget _buildJadwalTable() {
    if (_daftarJadwal.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Text('Tidak ada jadwal yang cocok.'),
        ),
      );
    }
    
    return SizedBox(
      width: double.infinity,
      child: DataTable(
        headingRowColor: WidgetStateProperty.all(Colors.pink[100]),
        columns: const [
          DataColumn(label: Text('Status')),
          DataColumn(label: Text('Judul')),
          DataColumn(label: Text('Kategori')),
          DataColumn(label: Text('Tanggal')),
          DataColumn(label: Text('Jam')),
          DataColumn(label: Text('Aksi')),
        ],
        rows: _daftarJadwal.asMap().entries.map((entry) {
          final int index = entry.key;
          final Jadwal jadwal = entry.value;
          
          return DataRow(cells: [
            DataCell(
              Checkbox(
                value: jadwal.status == 'Selesai',
                onChanged: (bool? newValue) {
                  setState(() {
                    jadwal.status = newValue! ? 'Selesai' : 'Pending';
                  });
                },
              ),
            ),
            DataCell(Text(jadwal.judul)),
            DataCell(Text(jadwal.kategori ?? '-')),
            DataCell(Text(jadwal.tanggal)),
            DataCell(Text(jadwal.jam)),
            DataCell(Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.edit, color: Colors.blue),
                  onPressed: () {
                    _bukaHalamanDetail(
                      jadwal: jadwal,
                      index: index,
                    );
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () {
                    setState(() {
                      _daftarJadwal.removeAt(index);
                    });
                  },
                ),
              ],
            )),
          ]);
        }).toList(),
      ),
    );
  }
}