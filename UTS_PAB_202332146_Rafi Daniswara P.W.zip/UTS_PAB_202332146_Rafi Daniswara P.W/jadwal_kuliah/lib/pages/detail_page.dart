// File: lib/pages/detail_page.dart

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/jadwal_model.dart';

class DetailPage extends StatefulWidget {
  final Jadwal? jadwalToEdit;

  const DetailPage({
    super.key,
    this.jadwalToEdit,
  });

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  final TextEditingController _judulController = TextEditingController();
  final TextEditingController _deskripsiController = TextEditingController();
  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _timeController = TextEditingController();
  String? _selectedCategory;

  bool isEditMode = false;

  @override
  void initState() {
    super.initState();
    if (widget.jadwalToEdit != null) {
      isEditMode = true;
      _judulController.text = widget.jadwalToEdit!.judul;
      _deskripsiController.text = widget.jadwalToEdit!.deskripsi;
      _dateController.text = widget.jadwalToEdit!.tanggal;
      _timeController.text = widget.jadwalToEdit!.jam;
      _selectedCategory = widget.jadwalToEdit!.kategori;
    }
  }

  @override
  void dispose() {
    _judulController.dispose();
    _deskripsiController.dispose();
    _dateController.dispose();
    _timeController.dispose();
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null) {
      setState(() {
        _dateController.text = DateFormat('dd/MM/yyyy').format(picked);
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      setState(() {
        final String formattedTime =
            '${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}';
        _timeController.text = formattedTime;
      });
    }
  }

  void _simpanJadwal() {
    if (_judulController.text.isEmpty ||
        _dateController.text.isEmpty ||
        _timeController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Judul, Tanggal, dan Jam tidak boleh kosong!'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final jadwalHasil = Jadwal(
      judul: _judulController.text,
      kategori: _selectedCategory,
      tanggal: _dateController.text,
      jam: _timeController.text,
      deskripsi: _deskripsiController.text,
      status: isEditMode ? widget.jadwalToEdit!.status : 'Pending',
    );
    
    Navigator.pop(context, jadwalHasil);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Aplikasi Pengingat Jadwal'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isEditMode ? '📝 Edit Jadwal' : '📝 Tambah Jadwal Baru',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 24),
                  _buildTextField(
                    label: 'Judul',
                    controller: _judulController,
                  ),
                  const SizedBox(height: 16),
                  _buildCategoryDropdown(),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: _buildDatePicker(context),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _buildTimePicker(context),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  _buildTextField(
                    label: 'Deskripsi',
                    controller: _deskripsiController,
                    maxLines: 4,
                  ),
                  const SizedBox(height: 32),
                  _buildActionButtons(context),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(
      {required String label,
      required TextEditingController controller,
      int maxLines = 1}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          maxLines: maxLines,
          decoration: InputDecoration(
            hintText: 'Masukkan $label...',
          ),
        ),
      ],
    );
  }

  Widget _buildCategoryDropdown() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Kategori', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          // --- INI PERBAIKANNYA ---
          initialValue: _selectedCategory, // <-- Mengganti 'value'
          hint: const Text('-- Pilih Kategori --'),
          decoration: const InputDecoration(),
          items: ['Pendidikan', 'Olahraga', 'Travel', 'Keuangan', 'Hobi']
              .map((label) => DropdownMenuItem(
                    value: label,
                    child: Text(label),
                  ))
              .toList(),
          onChanged: (value) {
            setState(() {
              _selectedCategory = value;
            });
          },
        ),
      ],
    );
  }

  Widget _buildDatePicker(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Tanggal', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        TextFormField(
          controller: _dateController,
          readOnly: true,
          decoration: const InputDecoration(
            hintText: 'dd/mm/yyyy',
            suffixIcon: Icon(Icons.calendar_month),
          ),
          onTap: () => _selectDate(context),
        ),
      ],
    );
  }

  Widget _buildTimePicker(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Jam', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        TextFormField(
          controller: _timeController,
          readOnly: true,
          decoration: const InputDecoration(
            hintText: '-- : --',
            suffixIcon: Icon(Icons.schedule),
          ),
          onTap: () => _selectTime(context),
        ),
      ],
    );
  }

  Widget _buildActionButtons(BuildContext context) {
    return Row(
      children: [
        ElevatedButton(
          onPressed: () {
            Navigator.pop(context);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.grey[600],
            foregroundColor: Colors.white,
          ),
          child: const Text('Kembali'),
        ),
        const Spacer(),
        ElevatedButton(
          onPressed: _simpanJadwal,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.pink,
            foregroundColor: Colors.white,
          ),
          child: Text(isEditMode ? 'Simpan Perubahan' : 'Simpan Jadwal'),
        ),
      ],
    );
  }
}