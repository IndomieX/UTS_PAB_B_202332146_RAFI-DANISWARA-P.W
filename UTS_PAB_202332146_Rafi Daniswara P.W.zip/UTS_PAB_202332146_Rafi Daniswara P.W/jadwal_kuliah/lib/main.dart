import 'package:flutter/material.dart'; // <-- KESALAHAN ANDA ADA DI SINI
// Import semua halaman yang kita daftarkan di 'routes'
import 'pages/login_page.dart';
import 'pages/dashboard_page.dart';
import 'pages/register_page.dart';
import 'pages/forgot_password_page.dart';
// Kita tidak perlu import 'detail_page.dart' di sini lagi

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aplikasi Pengingat Jadwal',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        // Tema utama aplikasi
        primarySwatch: Colors.pink,
        // Warna latar belakang utama
        scaffoldBackgroundColor: Colors.pink[50],
        // Tema untuk Card
        cardTheme: CardThemeData(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.0),
          ),
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        ),
        // Tema untuk Button
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12.0),
            ),
            padding: const EdgeInsets.symmetric(vertical: 16),
          ),
        ),
        // Tema untuk Input Field
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
            borderSide: BorderSide.none,
          ),
          filled: true,
          fillColor: Colors.grey[100],
        ),
        // Tema untuk App Bar
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.pink[50],
          elevation: 0,
          iconTheme: const IconThemeData(color: Colors.pink),
          titleTextStyle: const TextStyle(
            color: Colors.black87,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      
      // Halaman awal saat aplikasi dibuka
      initialRoute: '/login',
      
      // Definisikan semua rute navigasi aplikasi
      routes: {
        '/login': (context) => const LoginPage(),
        '/dashboard': (context) => const DashboardPage(),
        '/register': (context) => const RegisterPage(),
        '/forgot_password': (context) => const ForgotPasswordPage(),
        // Rute '/detail' sudah dihapus karena kita panggil manual
      },
    );
  }
}