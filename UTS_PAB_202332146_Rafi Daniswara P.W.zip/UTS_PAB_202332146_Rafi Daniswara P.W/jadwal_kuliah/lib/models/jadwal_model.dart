// File: lib/models/jadwal_model.dart

class Jadwal {
  final String judul;
  final String? kategori;
  final String tanggal;
  final String jam;
  final String deskripsi;
  String status; // 'Pending' atau 'Selesai'

  Jadwal({
    required this.judul,
    this.kategori,
    required this.tanggal,
    required this.jam,
    required this.deskripsi,
    this.status = 'Pending',
  });
}